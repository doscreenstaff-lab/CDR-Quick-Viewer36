CDR QUICK VIEWER
================

Versi: 1.0
Bahasa UI: Bahasa Melayu
Platform: Pelayar web pada Android, Windows, macOS dan Linux

PILIHAN 1 — GUNA TERUS (PALING MUDAH)
------------------------------------
1. Buka CDR_Viewer.html dengan pelayar moden.
2. Tekan "Pilih fail CDR" dan pilih fail .cdr.
3. Jika imej pratonton ditemui, ia akan dipaparkan. Tekan "Simpan pratonton" untuk menyimpan imej tersebut.

Pada sesetengah telefon Android, anda mungkin perlu buka fail HTML daripada aplikasi Fail dan pilih Chrome. Jika pelayar tidak membenarkan fail HTML tempatan, gunakan Pilihan 2.

PILIHAN 2 — PASANG SEBAGAI WEB APP
---------------------------------
Folder pwa mengandungi versi Progressive Web App (PWA). Untuk memasangnya sebagai ikon app pada telefon:
1. Hoskan kandungan folder pwa pada laman HTTPS statik (contohnya GitHub Pages atau Netlify).
2. Buka alamat HTTPS itu dalam Chrome pada Android.
3. Pilih menu Chrome > "Install app" atau "Add to Home screen" (nama pilihan mungkin berbeza).

Fail utama: CDR_Viewer.html
Versi PWA: folder pwa/
Tiada akaun atau pemasangan perpustakaan diperlukan.

PRIVASI
-------
Fail dibaca secara setempat pada peranti. Aplikasi ini tidak menghantar fail ke pelayan. Pautan "Cuba pembaca penuh" hanya membuka pembaca vektor CDR dalam talian; pautan ini membuka laman luar. Laman pembaca itu menyatakan pemprosesan fail berlaku di pelayar, tetapi semak maklumat privasi semasa sebelum menggunakannya.

HAD PENTING
------------
Ini ialah alat pratonton, bukan editor CorelDRAW dan bukan penukar vektor penuh. Ia cuba mengekstrak imej yang sudah tersimpan di dalam fail CDR. Sesetengah fail/versi CDR tidak menyimpan pratonton yang boleh dibaca, atau menyimpan struktur yang tidak disokong oleh pelayar. Dalam keadaan itu, aplikasi mungkin tidak dapat memaparkan reka bentuk. Untuk melihat dan menyunting semua objek vektor, gunakan CorelDRAW atau pembaca/penukar yang benar-benar menyokong versi fail tersebut.
